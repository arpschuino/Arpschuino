
#ifndef Arpschuino_h
#define Arpschuino_h

#define default_adress (1)//adresse par defaut

bool led_temoin ();//change l'etat (allume ou eteind) de la led verte de l'arpschuino



void arpdress_board();//prend l'adresse depuis l'arpdress board, l'ecrit dans l'EEPROM

#endif
