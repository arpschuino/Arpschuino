/*
000         ---------------------
001-512     DMX start address
513         RFM12 receiver mode
514-601     ---------------------
602-666     NOMBRE DE CIRCUITS n-600 Circuits
667-739     ---------------------
740-760     frequency fine
761-867     ---------------------
868         RF12_868MHZ frequency range
869-914     ---------------------
915         RF12_915MHZ frequency range
916-998     ---------------------
999         reload default
*/
