#ifndef FONCTIONS_H
#define FONCTIONS_H

#define default_adress (1)//adresse par defaut

void led_temoin ();//change l'etat (allume ou eteind) de la led verte de l'arpschuino

void arpdress_board();//prend l'adresse depuis l'arpdress board, l'ecrit dans l'EEPROM

#endif

